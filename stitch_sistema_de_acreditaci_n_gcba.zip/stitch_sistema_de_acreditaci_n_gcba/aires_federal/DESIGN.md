```markdown
# The Civic Architect: A Design System for Modern Governance

## 1. Overview & Creative North Star

This design system moves beyond the standard bureaucratic "template" to establish a visual language of **Structured Transparency**. Our goal is to transform the citizen's digital experience from a chore into a high-end editorial journey. We don't just provide information; we architect clarity.

**Creative North Star: "The Civic Architect"**
The design system draws inspiration from the intersection of classic Buenos Aires architecture and modern digital efficiency. It utilizes intentional asymmetry, expansive negative space, and a sophisticated layering of surfaces to create a sense of trust, authority, and accessibility. By rejecting rigid grid lines in favor of tonal transitions, we create a UI that feels fluid, human, and premium.

---

## 2. Colors & Tonal Depth

In this system, color is not just decoration—it is functional infrastructure. 

### The Palette
- **Primary Foundation:** `primary_container` (#153244) provides the authoritative weight.
- **The Action Signal:** `secondary_container` (#FFCC00) is used exclusively for high-priority calls to action and critical focus states.
- **Supportive Clarity:** `tertiary_fixed` (#8DE2D6) acts as a breath of fresh air, used for secondary data points and soft status indicators.
- **The Canvas:** `background` (#FCFCFC) is our neutral ground, providing the high-contrast foundation required for legibility.

### Surface Hierarchy & The "No-Line" Rule
To achieve a high-end editorial feel, **1px solid borders are strictly prohibited for sectioning.** We define boundaries through background color shifts.
- **Nesting:** Place a `surface_container_lowest` card on top of a `surface_container_low` section to create natural separation.
- **The Layering Principle:** Treat the interface as physical layers of fine paper. Use `surface_container` levels (Lowest to Highest) to denote information priority. An "inner" data module should always sit on a surface one tier higher or lower than its parent to define its footprint.

### The "Glass & Gradient" Rule
Flat color can feel "dead." To inject visual "soul":
- Use **Glassmorphism** for floating navigation or sticky headers. Apply a semi-transparent `surface` color with a `20px` backdrop-blur to allow the content beneath to subtly influence the header’s tone.
- Use **Signature Gradients** for hero sections. Transition from `primary` (#001d2d) to `primary_container` (#153244) at a 135-degree angle to add depth without sacrificing institutional gravity.

---

## 3. Typography: The Editorial Voice

We use **Public Sans** to balance professional neutrality with modern warmth. Typography is our primary tool for establishing hierarchy.

- **Display Scale:** Use `display-lg` and `display-md` with tight letter-spacing (-0.02em) for hero headlines. These should feel like a broadsheet newspaper—authoritative and unavoidable.
- **Intentional Contrast:** Pair a `display-sm` headline with a `body-md` description. The jump in scale creates an editorial rhythm that guides the eye.
- **Functional Labels:** Use `label-md` in all-caps with increased letter-spacing (+0.05em) for category tags or table headers to provide a "utility" feel that contrasts with the fluid headlines.

---

## 4. Elevation & Depth

We avoid the "pasted-on" look of traditional shadows. Depth in this system is organic.

- **Ambient Shadows:** When a floating element (like a modal) is required, use a shadow color tinted with `on_surface`. 
    - *Formula:* `0px 12px 32px rgba(26, 28, 28, 0.08)`. This creates a soft, architectural lift.
- **The Ghost Border:** If a boundary is strictly necessary for accessibility (e.g., in high-density data tables), use a "Ghost Border"—the `outline_variant` token at 15% opacity. It should be felt, not seen.
- **Tonal Layering:** Most hierarchy should be achieved by stacking `surface_container_lowest` cards on a `surface_container` background. This creates a "soft lift" that feels more premium than a drop shadow.

---

## 5. Components

### High-Contrast Buttons
- **Primary Action:** `secondary_container` (#FFCC00) background with `on_secondary_fixed` (#241a00) text. Use the `lg` (8px) corner radius. 
- **The Hover State:** Transition to `on_secondary_fixed_variant` for a subtle darkening that maintains high contrast.
- **Tertiary/Ghost:** No background, only `primary_container` text with a `label-md` weight.

### Structured Data Tables
- **Strictly no vertical lines.** 
- Use `surface_container_low` for the header row.
- Use a `surface_container_lowest` background for the table body.
- Separation is achieved through vertical whitespace (16px between rows) and subtle `surface_container_high` zebra-striping on hover.

### Status Badges
- Use `tertiary_fixed` (#8DE2D6) for "Neutral/Active" states. 
- Text should always be the high-contrast `on_tertiary_fixed` (#00201d).
- Shape: Use the `full` (9999px) roundedness to distinguish badges from buttons.

### Interactive Inputs
- **Base State:** `surface_container_highest` background with a bottom-only "Ghost Border" (2px).
- **Focus State:** The bottom border transforms into a 2px `secondary_container` (Yellow) line, signaling an active gateway.

---

## 6. Do’s and Don'ts

### Do
- **Use Asymmetry:** Align text to the left but place supporting imagery or data visualizations slightly off-center to create a modern, curated look.
- **Embrace White Space:** Allow at least `2.5rem` of padding between major sections to let the "Civic Architect" style breathe.
- **Prioritize Legibility:** Always check that `on_primary` text sits on `primary` backgrounds with a minimum 4.5:1 ratio.

### Don’t
- **Don’t use 100% Black:** Use `primary` (#001d2d) for text to maintain the sophisticated blue-tinted depth of the system.
- **Don’t use standard shadows:** Never use default `rgba(0,0,0,0.5)` shadows. They look "cheap" and dated.
- **Don’t use dividers:** Avoid horizontal lines between list items. Use the `surface_container` background shift or a `1rem` vertical gap instead.

---

*This design system is a living framework. Every element must serve the citizen’s need for clarity while upholding the prestige of the City.*```